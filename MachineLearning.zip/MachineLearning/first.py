# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""


import numpy as np
import matplotlib.pyplot as plit
import pandas as pd
dataset = pd.read_csv('D://MCA//ML//firstt.csv')
dataset
print(dataset.columns)
dataset
x = dataset.iloc[:,:-1].values
y = dataset.iloc[:, -1].values
x
y

from sklearn.impute import SimpleImputer
imputer = SimpleImputer(missing_values = np.NAN, strategy='mean')
imputer = imputer.fit(x[:, 3:4])
x[:, 3:4] = imputer.transform(x[:, 3:4])
x

from sklearn.impute import SimpleImputer
imputer = SimpleImputer(missing_values = np.NAN, strategy='median')
imputer = imputer.fit(x[:, 3:4])
x[:, 3:4] = imputer.transform(x[:, 3:4])
x

# EXAMPLE 1
import pandas as pd
dataset = pd.read_csv("D:\\MCA\\ML\\firstt.csv")
X = dataset.iloc[:,:-1].values
Y = dataset.iloc[:,-1].values
X
Y
print(dataset.columns)
dataset
dataset.info()
dataset.head()
dataset.tail()
dataset.shape #Row column count
dataset.isnull().sum().sort_values(ascending=False)  #count Missing Values 
dataset.isnull().sum()

#Removing Insufficient column
dataset_new = dataset.drop(['salary',],axis=1)
dataset_new
dataset

#measure the central tendacy 
dataset_new.describe()

#Change nameof column
dataset.rename(index=str, columns={'name':'Names','salery':'salary'})
dataset

#Remove missing value
ds_new = dataset.dropna()
ds_new
dataset.shape
ds_new.isnull().sum()

#check datatypes
ds_new.dtypes
ds_new['salary'] = ds_new['salary'].astype('int64')

